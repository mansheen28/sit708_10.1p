package com.example.personalizedlearningexperience;

public interface OnRadioButtonClickListener {
    void onRadioButtonClicked(int position, String radioButtonLabel);
}
